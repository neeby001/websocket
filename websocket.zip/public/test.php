<?
echo $_POST['mes'];
?>
