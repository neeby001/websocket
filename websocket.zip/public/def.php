<?
session_start();
//$connect = mysqli_connect('localhost', 'e952951e_db', '3f57wow395G', 'e952951e_db');
$connect = mysqli_connect('localhost', 'root', 'root', 'firstdb');
?>
